 #include <stdio.h>
  #include <conio.h>
  #include <graphics.h>
  #include <dos.h>

  /* draw petals of a flower with given color */
  void drawflower(int x1, int y1, int radius, int color, int angle) {
        angle = angle * 4;
        setcolor(color);
        setfillstyle(SOLID_FILL, color);
        pieslice(x1, y1, 10 + angle, 80 - angle, radius);
        pieslice(x1, y1, 100 + angle, 170 - angle, radius);
        pieslice(x1, y1, 190 + angle, 260 - angle, radius);
        pieslice(x1, y1, 280 + angle, 350 - angle, radius);
        return;
  }

  int main() {
        /* request auto detection */
        int gdrive = DETECT, gmode, err;
        int radius, x[4], y[4], r[4];
        int i, j, k, temp, color[5];

        /* initialize graphic mode */
        initgraph(&gdrive, &gmode, "C://TC//BGI");
        err = graphresult();

        if (err != grOk) {
                /* error occurred */
                printf("Graphics Error: %s\n",
                                grapherrormsg(err));
                return 0;
        }

        /* assinging center position of flowers */
        x[0] = x[2] = getmaxx() / 4;
        x[1] = x[3] = 3 * getmaxx() / 4;

        y[0] = y[1] = getmaxy() / 4;
        y[2] = y[3] = 3 * getmaxy() / 4;

        /* colors for the flowers */
        color[0] = YELLOW, color[1] = GREEN;
        color[2] = BLUE, color[3] = CYAN;
        color[4] = LIGHTRED;


        while (!kbhit()) {
                /* clears the graphic screen */
                cleardevice();

                /* flower radius */
                radius = 110;
                for (j = 0; j < 5; j++) {
                        temp = color[0];
                        for (k = 1; k < 5; k ++) {
                                color[k - 1] = color[k];
                        }

                        color[4] = temp;

                        /* draws petals of flowers - one by one */
                        drawflower(x[0], y[0], radius, color[0], j);
                        drawflower(x[1], y[1], radius, color[1], j);
                        drawflower(x[2], y[2], radius, color[2], j);
                        drawflower(x[3], y[3], radius, color[3], j);
                        radius = radius - 20;
                        delay(200);
                }

                /* draw stigma(center part) in all 4 flowers */
                setcolor(RED);
                setfillstyle(SOLID_FILL, RED);
                circle(x[0], y[0], 5);
                circle(x[1], y[1], 5);
                circle(x[2], y[2], 5);
                circle(x[3], y[3], 5);
                floodfill(x[0], y[0], RED);
                floodfill(x[1], y[1], RED);
                floodfill(x[2], y[2], RED);
                floodfill(x[3], y[3], RED);

                /* sleep for 300 milliseconds */
                delay(300);
        }

        getch();
        /* deallocate memory allocated for graphic screen */
        closegraph();
        return 0;
  }