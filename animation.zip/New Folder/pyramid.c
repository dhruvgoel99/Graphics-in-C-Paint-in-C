#include <stdio.h>
  #include <conio.h>
  #include <graphics.h>
  #include <dos.h>

  int main() {
        /* request auto detection */
        int gdriver = DETECT, gmode, err;
        int color, fillstyle, poly[10];
        int i, midx, midy;

        /* initialize graphic device */
        initgraph(&gdriver, &gmode, "C://TC//BGI");
        err = graphresult();

        if (err != grOk) {
                /* error occurred */
                printf("Graphics Error: %s",
                                grapherrormsg(err));
                return 0;
        }

        /* mid positions in x and y-axis */
        midx = getmaxx() / 2;
        midy = getmaxy() / 2;

        color = WHITE;
        fillstyle = WIDE_DOT_FILL;

        /* drawing triangle at the top of the pyramid */
        setcolor(color);
        setfillstyle(fillstyle, color);
        poly[0] = midx, poly[1] = midy - 100;
        poly[2] = midx - 20, poly[3] = midy - 70;
        poly[4] = midx + 20, poly[5] = midy - 70;
        poly[6] = midx, poly[7] = midy - 100;
        drawpoly(4, poly);
        floodfill(midx - 18, midy - 72, color);
        sleep(1);

        /* drawing second top layer of the pyramid */
        color--, fillstyle--;
        setcolor(color);
        setfillstyle(fillstyle, color);
        poly[0] = midx - 20, poly[1] = midy - 70;
        poly[2] = midx + 20, poly[3] = midy - 70;
        poly[4] = midx + 40, poly[5] = midy - 40;
        poly[6] = midx - 40, poly[7] = midy - 40;
        poly[8] = midx - 20, poly[9] = midy - 70;
        drawpoly(5, poly);
        floodfill(poly[0] + 1, poly[1] + 1, color);
        sleep(1);

        /* drawing subsequent layer of the pyramids */
        for (i = 0; i < 8; i++) {
                color--, fillstyle--;
                setcolor(color);
                setfillstyle(fillstyle, color);
                poly[0] = poly[0] - 20, poly[1] = poly[1] + 30;
                poly[2] = poly[2] + 20, poly[3] = poly[3] + 30;
                poly[4] = poly[4] + 20, poly[5] = poly[5] + 30;
                poly[6] = poly[6] - 20, poly[7] = poly[7] + 30;
                poly[8] = poly[8] - 20, poly[9] = poly[9] + 30;
                drawpoly(5, poly);
                floodfill(poly[0] + 1, poly[1] + 1, color);
                sleep(1);
        }

        getch();

        /* deallocate memory allocated for graphic screen */
        closegraph();
        return 0;
  }