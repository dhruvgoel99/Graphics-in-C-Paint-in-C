#include<graphics.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#define rads 0.0174
int x = 280,y = 350,numbranch = 3;
float spreadratio = 0.5,lenratio=1.0;

main()
{
int gdriver = DETECT, gmode;
int drawtree(int x1,int y1,float a,float l,float f,int n);
initgraph(&gdriver, &gmode, ""); // Init the graphics mode.
drawtree(x,y,270,50,90,6);
getch();
closegraph(); // Exit graphics mode.
restorecrtmode();
}

drawtree(int x1, int y1,float a,float l ,float f,int n)
{int i,num,color,x2,y2;
float delang,ang;
if (n>0)
{
 switch(n)
{ case 1:
setcolor(LIGHTGREEN);
break;
case 2:
setcolor(GREEN);
break;
case 3:
setcolor(RED);
break;
case 4:
setcolor(BROWN);
break;
default:
setcolor(DARKGRAY);
break;
}
x2 = x1+l * cos(rads * a);
y2 = y1+l * sin(rads * a);

for(i=0;i<n;i++)
{
line(x1+i,y1,x2+i,y2);
line(x1-i,y1,x2-i,y2);
}
num = random(6)+1 ;

if( num > 1 )
{delang = f/(num-1.0);
}
else
{delang = 0.0;
 }
ang = a-f/2.0 - delang;

for(i = 1;i<=num;i++)
{
ang += delang;
drawtree(x2,y2,ang+10,l*lenratio,1.0*random(90)+1,-1);
}
}
else
{
setfillstyle(SOLID_FILL,random(15));
fillellipse(x1,y1,3,6);
}
}

