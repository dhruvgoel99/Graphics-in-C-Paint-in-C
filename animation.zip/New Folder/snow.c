#include <stdio.h>
  #include <conio.h>
  #include <math.h>
  #include <graphics.h>
  #include <dos.h>

  /* clears/creates snow based on the given color */
  void whitePixel(int color) {
        int i, j = 0, x, y;
        setlinestyle(SOLID_LINE, 1, 3);
        setcolor(color);

        for (i = 50; i < 600; i = i + 50) {
                x = i;
                y = 50 + j;

                /* put pixel at the given position */
                putpixel(x, y, color);

                /* moving the snow(pixels) towards moutain */
                if (i % 100 == 0) {
                        y = y + 90;
                        x = x + 35;
                        j = 20;
                }  else {
                        y = y +  130;
                        x = x + 25;
                        if (i > 450) {
                                j = 160;
                        } else {
                                j = 30;
                        }
                }

                /* put pixel at the given position */
                putpixel(x, y, color);
        }
        return;
  }

  void snowFall(int color) {
        int i, j, x, y;

        setlinestyle(SOLID_LINE, 1, 3);
        setcolor(color);

        for (i = 25; i < 600; i = i + 25) {
                x = i;
                y = 100 + j;
                putpixel(x, y, color);

                if (i % 100 == 0) {
                        y = y + 90;
                        x = x + 35;
                        j = 20;
                }  else {
                        y = y +  130;
                        x = x + 25;
                        j = 30;
                }
                putpixel(x, y, color);
        }
        return;
  }

  int main() {
        /* request auto detection */
        int gdriver = DETECT, gmode, err;
        int i = 0, fq, amp;
        double x, y;

        /* initialize graphic mode */
        initgraph(&gdriver, &gmode, "C:/TURBOC3/BGI");
        err = graphresult();

        if (err != grOk) {
                /* error occurred */
                printf("Graphics Error: %s\n",
                                grapherrormsg(err));
                return 0;
        }

        x = 0;
        fq = 2;
        amp = 100;
        setcolor(WHITE);

        /* drawing the moutain using sine wave */
        while (x <= getmaxx()) {
                y = amp * sin((3.14 * fq * x) / 180);
                y = y + getmaxy() / 2 + 100;
                putpixel(x, y, 15);
                line(x, y, x, y - 12);
                line(x, y, x, y + 12);
                delay(10);
                x = x + 1;
        }

        /* color the mountain with white(snow) */
        setfillstyle(SOLID_FILL, WHITE);
        floodfill(2, getmaxy(), WHITE);

        /* draw the moon */
        x = getmaxx() - 50;
        y = 40;
        setcolor(LIGHTRED);
        setfillstyle(SOLID_FILL, LIGHTRED);
        circle(x, y, 25);
        floodfill(x, y, LIGHTRED);

        /* drawing birds */
        setlinestyle(SOLID_LINE, 1, 3);
        setcolor(WHITE);
        arc(50, 50, 0, 160, 10);
        arc(70, 50, 20, 180, 10);
        arc(150, 100, 0, 150, 10);
        arc(170, 100, 10, 180, 10);
        arc(250, 125, 0, 160, 10);
        arc(270, 125, 20, 180, 10);

        /* snowfall */
        for (i = 0; i < 100; i++) {
                whitePixel(WHITE);
                snowFall(BLACK);
                delay(100);
                whitePixel(BLACK);
                snowFall(WHITE);
                delay(100);
        }

        whitePixel(WHITE);

        getch();

        /* deallocate memory allocated for graphic screen */
        closegraph();

        return 0;
  }