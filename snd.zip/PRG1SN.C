#include <stdio.h>
#include <dos.h>

void my_sounds(void);

int music(int pitch, int time)
{
sound(pitch);
delay(time);
nosound();
return(0);
}


void       my_sounds(void)
 {
      sound(130);            /* make a sound at 500 Hz.*/
      delay(2000);            /* pause for 2000 milliseconds = 2 seconds  */
      nosound();
      return(0);

      sound(137);
      delay(2000);
      nosound();
      return(0);

      sound(145);
      delay(2000);
      nosound();
      return(0);

      sound(155);
      delay(2000);
      nosound();
      return(0);

      sound(166);
      delay(2000);
      nosound();
      return(0);

      sound(176);
      delay(2000);
      nosound();
      return(0);

      sound(185);
      delay(2000);
      nosound();
      return(0);

      sound(195);
      delay(2000);
      nosound();
      return(0);

      sound(207);
      delay(2000);
      nosound();
      return(0);

      sound(220);
      delay(2000);
      nosound();
      return(0);

      sound(235);
      delay(2000);
      nosound();
      return(0);

      sound(260);
      delay(2000);
      nosound();
      return(0);

      sound(275);
      delay(2000);
      nosound();
      return(0);

      sound(290);
      delay(2000);
      nosound();
      return(0);

      sound(311);
      delay(2000);
      nosound();
      return(0);

      sound(333);
      delay(2000);
      nosound();
      return(0);

      sound(350);
      delay(2000);
      nosound();
      return(0);

      sound(370);
      delay(2000);
      nosound();
      return(0);

      sound(390);
      delay(2000);
      nosound();
      return(0);

      sound(415);
      delay(2000);
      nosound();
      return(0);

      sound(440);
      delay(2000);
      nosound();
      return(0);

      sound(470);
      delay(2000);
      nosound();
      return(0);

      sound(490);
      delay(2000);
      nosound();
      return(0);

      sound(520);
      delay(2000);      
      nosound();            /* turn off sound      */
      return(0);
 }
