void main()
{
clrscr();
printf("These are few cricketers");
 
sound(2000);
delay(1000);
printf("\n\n\t\tRicky");
nosound();
delay(1000);
 
sound(2100);
delay(1000);
printf("\n\n\t\tYuvraj");
nosound();
delay(1000);
 
sound(2200);
delay(1000);
printf("\n\n\t\tVirendra Sehwag");
nosound();
delay(1000);
 
sound(2300);
delay(1000);
printf("\n\n\t\tGayle");
nosound();
delay(1000);
 
sound(2400);
delay(1000);
printf("\n\n\t\tBailey");
nosound();
delay(1000);
printf("\nPress any key to end......");
getch();
}//main