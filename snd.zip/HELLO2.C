
/*	HELLO.C -- Hello, world */

#include <stdio.h>

int main()
{       int i,j;
	delay(1);
	for(j=0;j<3;j++)
	{
	for(i=0;i<=10;i++)
	{
	sound(150+i*10);
	delay(100);
	}
	nosound();
	}
	printf("Hello, world\n");




	return 0;
}
