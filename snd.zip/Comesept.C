#include<stdio.h>
#include<dos.h>
#include<math.h>
main()
{
sound(1498.307);
delay(250);

sound(1334.840);
delay(250);

sound(1189.207);
delay(250);

sound(1122.462);
delay(250);

sound(1000);
delay(1000);

sound(1189.207);
delay(1000);

sound(1498.307);
delay(1000);

sound(2000);
delay(500);

sound(1498.307);
delay(500);

sound(1334.840);
delay(1000);

sound(1498.307);
delay(1000);

sound(2000);
delay(500);

sound(1587.401);
delay(750);

sound(1334.840);
delay(750);

sound(1493.807);
delay(1000);

sound(1334.840);
delay(500);

sound(1189.207);
delay(500);

sound(1122.462);
delay(500);

sound(1189.207);
delay(250);

sound(1122.462);
delay(250);

sound(1000);
delay(1500);


nosound();
}