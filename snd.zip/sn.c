#include<dos.h>
main()
{ sound(150);
delay(2.5);
sound(133);
delay(2.5);
sound(118);
delay(2.5);
sound(112);
delay(2.5);

sound(100);
delay(10);
sound(118);
delay(10);
sound(150);
delay(10);

sound(200);
delay(5);
sound(150);
delay(5);

sound(133);
delay(10);
sound(150);
delay(10);

sound(200);
delay(5);

sound(158);
delay(5);
sound(133);
delay(5);
sound(150);
delay(5);

sound(133);
delay(3.5);

sound(119);
delay(3.5);

sound(112);
delay(3);
sound(119);
delay(3);
sound(112);
delay(3);
sound(100);
delay(5);

nosound();
}