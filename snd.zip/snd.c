#include <stdio.h>
#include <dos.h>

void my_sounds(void);

int music(int pitch, int time)
{
sound(pitch);
delay(time);
nosound();
return(0);
}


void       my_sounds(void)
 {
      sound(130);            /* make a sound at 500 Hz.*/
      delay(2000);            /* pause for 2000 milliseconds = 2 seconds  */
      nosound();
      return(0);

      sound(137);
      delay(2000);
      nosound();
      return(0);

      sound(145);
      delay(2000);
      nosound();
      return(0);

      sound(155);
      delay(2000);
      nosound();
      return(0);

      sound(166);
      delay(2000);
      nosound();
      return(0);

      sound(176);
      delay(2000);
      nosound();
      return(0);

      sound(185);
      delay(2000);
      nosound();
      return(0);

      sound(195);
      delay(2000);
      nosound();
      return(0);

      sound(207);
      delay(2000);
      nosound();
      return(0);

      sound(220);
      delay(2000);
      nosound();
      return(0);

      sound(235);
      delay(2000);
      nosound();
      return(0);

      sound(260);
      delay(2000);
      nosound();
      return(0);

      sound(275);
      delay(2000);
      nosound();
      return(0);

      sound(290);
      delay(2000);
      nosound();
      return(0);

      sound(311);
      delay(2000);
      nosound();
      return(0);

      sound(333);
      delay(2000);
      nosound();
      return(0);

      sound(350);
      delay(2000);
      nosound();
      return(0);

      sound(370);
      delay(2000);
      nosound();
      return(0);

      sound(390);
      delay(2000);
      nosound();
      return(0);

      sound(415);
      delay(2000);
      nosound();
      return(0);

      sound(440);
      delay(2000);
      nosound();
      return(0);

      sound(470);
      delay(2000);
      nosound();
      return(0);

      sound(490);
      delay(2000);
      nosound();
      return(0);

      sound(520);
      delay(2000);      
      nosound();            /* turn off sound      */
      return(0);
 }

Does anyone know how i would go about generating some type of wave function which can play musical notes in C programming. 

Many Thanks,

Teknologik
 Comment
Question by:
teknologik
  
 
LVL 53
Best Solution byInfinity08
>> how would i created the main() which calls my_sounds(). I've added the main in the code below : #include <stdio.h> #include <dos.h> void my_sounds(void); int music(int pitch, int time)
Go to Solution
  16   13   
30 Comments
 
LVL 53
Expert Commentby:Infinity08
ID: 190716332007-05-11
Try this :

#include <stdio.h>
#include <dos.h>

void my_sounds(void);

int music(int pitch, int time)
{
sound(pitch);
delay(time);
nosound();
return(0);
}


void       my_sounds(void)
 {
      music(130, 2000);
      music(137, 2000);
      music(145, 2000);
      music(155, 2000);
      music(166, 2000);
      music(176, 2000);
      music(185, 2000);
      music(195, 2000);
      music(207, 2000);
      music(220, 2000);
      music(235, 2000);
      music(260, 2000);
      music(275, 2000);
      music(290, 2000);
      music(311, 2000);
      music(333, 2000);
      music(350, 2000);
      music(370, 2000);
      music(390, 2000);
      music(415, 2000);
      music(440, 2000);
      music(470, 2000);
      music(490, 2000);
      music(520, 2000);      
 }