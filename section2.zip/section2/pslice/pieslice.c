/* program pieslice*/

#include<stdio.h>
  #include<graphics.h>
  #include<conio.h>
   void main()
  {
              int gd=DETECT, gm;
               initgraph(&gd,&gm," ");
               pieslice(320,240,0,75,100);
               getch();
               closegraph();
}