#include<stdio.h> 
#include<graphics.h>
 #include<conio.h> 
void main() 
{ int gd=DETECT, gm;
 initgraph(&gd,&gm," "); 
setbkcolor(GREEN);
 circle(320,240,100);
 getch();
 closegraph(); }
