#include<graphics.h>
void main()
{
  int g_driver, g_mode,i,j=0;


  detectgraph(&g_driver, &g_mode);
  initgraph(&g_driver, &g_mode, "..\\bgi");
  for(i=0;i<15;i++)
  {setcolor(i);
  circle(320,100,j+i);
  j= j+10;}
  getch();
  closegraph();
  return;
}
