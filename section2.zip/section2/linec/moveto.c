/*moveto*/
#include<stdio.h>
  #include<graphics.h>
  #include<conio.h>
   void main()
{
   int gd = DETECT, gm,x,y;
   char arr[100];
   initgraph(&gd, &gm, " "); 
   x=getx();
   y=gety();
  sprintf(arr, "current position before using moveto() function is (%d,%d).",x,y);
   outtextxy(100,200,arr);
   moveto(50, 50);
   x=getx();
   y=gety();
  sprintf(arr, "current position after using moveto() function is (%d,%d).",x,y);
   outtextxy(100,240,arr);
   getch();
   closegraph();
}
