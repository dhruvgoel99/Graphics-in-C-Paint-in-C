/*getlinestyle function*/
#include <graphics.h>
  #include <stdlib.h>
  #include <stdio.h>
  #include <conio.h>

  int main(void) {
        /* request auto detection */
        int graphicDriver = DETECT;
        int graphicMode, err;
        struct linesettingstype linfo;
        char linestyle[128], pattern[128], thickness[128];

        char *style[] = { "solid line", "dotted line",
                          "center line", "dashed line",
                          "user bit line" };


        /* initialize graphics and local variables */
        initgraph(&graphicDriver, &graphicMode, "C:/TURBOC3/BGI");

        /* read result of initialization */
        err = graphresult();

        if (err != grOk) {
                /* an error occurred */
                printf("Graphic Error: %s\n",
                                grapherrormsg(err));
                getch();
                return 0;
        }

        /* get information about current line settings */
        getlinesettings(&linfo);

        /* convert line information into strings */
        sprintf(linestyle, "Line style: %s", style[linfo.linestyle]);
        sprintf(pattern, "Line pattern: 0x%x", linfo.upattern);
        sprintf(thickness, "Line thickness: %d", linfo.thickness);
        line(200, 100, 500, 100);

        /* display the information */
        settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(getmaxx() / 2, 120, linestyle);
        outtextxy(getmaxx() / 2, 140, pattern);
        outtextxy(getmaxx() / 2, 160, thickness);

        /* setting the line style */
        setlinestyle(DOTTED_LINE, 1, 1);

        /* fetching the current line style, pattern and thickness */
        getlinesettings(&linfo);
        sprintf(linestyle, "Line style: %s", style[linfo.linestyle]);
        sprintf(pattern, "Line pattern: 0x%x", linfo.upattern);
        sprintf(thickness, "Line thickness: %d", linfo.thickness);
        line(200, 200, 500, 200);

        /* display the information */
        settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(getmaxx() / 2, 220, linestyle);
        outtextxy(getmaxx() / 2, 240, pattern);
        outtextxy(getmaxx() / 2, 260, thickness);

        /* changing the line style */
        setlinestyle(DASHED_LINE, 1, 3);

        /* again fetching the current line settings */
        getlinesettings(&linfo);
        sprintf(linestyle, "Line style: %s", style[linfo.linestyle]);
        sprintf(pattern, "Line pattern: 0x%x", linfo.upattern);
        sprintf(thickness, "Line thickness: %d", linfo.thickness);
        line(200, 300, 500, 300);

        /* display the information */
        settextjustify(CENTER_TEXT, CENTER_TEXT);
        outtextxy(getmaxx() / 2, 320, linestyle);
        outtextxy(getmaxx() / 2, 340, pattern);
        outtextxy(getmaxx() / 2, 360, thickness);

        /* clean up */
        getch();
        closegraph();
        return 0;
  }
