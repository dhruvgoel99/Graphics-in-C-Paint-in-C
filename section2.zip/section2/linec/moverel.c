/*moverel fumction*/
#include<stdio.h>
  #include<graphics.h>
  #include<conio.h>
   void main()
{
   int gd = DETECT, gm, x, y;
   char arr[100];
   initgraph(&gd, &gm, " ");
   x = getx();
   y = gety();
  sprintf(arr, "Current position before using moveto() function is (%d,%d).", x, y);
   outtextxy(100,200, arr);
   moveto(100, 100);
   x = getx();
   y = gety();
  sprintf(arr, "Current position after using moveto() function is (%d,%d).", x, y);
   outtextxy(100,240, arr);
   moverel(100, -100);
   x = getx();
   y = gety();
sprintf(arr, "Current position after using moverel() function is (%d,%d).", x, y);
   outtextxy(100,280, arr);
   getch();
   closegraph();
}