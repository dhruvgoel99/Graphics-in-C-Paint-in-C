#include <graphics.h>
#include <conio.h>

int main()
{
int gdriver = DETECT, gmode;
int triangle[8];
// Let's define a triangle with vertices at A(1, 1), B(30, 100), and C(100, 150).
triangle[0] = 1; // x of vertex A.
triangle[1] = 1; // y of vertex A.
triangle[2] = 30; // x of vertex B.
triangle[3] = 100; // y of vertex B.
triangle[4] = 100; // x of vertex C.
triangle[5] = 150; // y of vertex C.
triangle[6] = triangle[0]; // Close triangle.
triangle[7] = triangle[1];

initgraph(&gdriver, &gmode, ""); // Init the graphics mode.
setcolor(RED);// Set color to white.
drawpoly(4, triangle); // Dr
getch();
closegraph(); // Exit graphics mode.
return 0;
}
