#include <stdio.h>
  #include <conio.h>
  #include <graphics.h>
  #include <dos.h>

  int main() {
        /* request auto detection */
        int gdriver = DETECT, gmode, err;
        int midx, midy;
        char str[64];

        /* initialize graphic mode */
        initgraph(&gdriver, &gmode, "C:/TURBOC3/BGI");
        err = graphresult();

        if (err != grOk) {
                /* error occurred */
                printf("Graphics Error: %s",
                                grapherrormsg(err));
                return 0;
        }

        /* mid positions in x and y-axis */
        midx = getmaxx() / 2;
        midy = getmaxy() / 2;

        /* pie slice representing safari */
        delay(100);
        setcolor(YELLOW);
        setfillstyle(CLOSE_DOT_FILL, YELLOW);
        pieslice(midx, midy, 0, 40, 100);

        /* pie slice representing firefox */
        delay(100);
        setcolor(LIGHTRED);
        setfillstyle(LINE_FILL, LIGHTRED);
        pieslice(midx, midy, 45, 140, 100);

        /* pie slice representing opera */
        delay(100);
        setcolor(CYAN);
        setfillstyle(WIDE_DOT_FILL, CYAN);
        pieslice(midx, midy, 145, 200, 100);

        /* pie slice representing chrome */
        delay(100);
        setcolor(LIGHTMAGENTA);
        setfillstyle(SLASH_FILL, LIGHTMAGENTA);
        pieslice(midx, midy, 205, 300, 100);

        /* pie slice representing internet explorer */
        delay(100);
        setcolor(LIGHTGREEN);
        setfillstyle(BKSLASH_FILL, LIGHTGREEN);
        pieslice(midx, midy, 305, 355, 100);

        /* naming pie slice with corresponding names */
        delay(100);
        setcolor(WHITE);
        settextstyle(TRIPLEX_FONT, HORIZ_DIR, 3);
        settextjustify(CENTER_TEXT, CENTER_TEXT);
        sprintf(str, "%s", "SAFARI");
        moveto(midx + 140, midy - 40);
        outtext(str);

        delay(100);
        sprintf(str, "%s", "FIREFOX");
        moveto(midx, midy - 130);
        outtext(str);

        delay(100);
        sprintf(str, "%s", "OPERA");
        moveto(midx - 140, midy);
        outtext(str);

        delay(100);
        sprintf(str, "%s", "CHROME");
        moveto(midx - 20, midy + 110);
        outtext(str);

        delay(100);
        sprintf(str, "%s", "IE");
        moveto(midx + 120, midy + 40);
        outtext(str);

        /* pie chart for various browsers */
        delay(100);
        setcolor(YELLOW);
        sprintf(str, "%s", "PIE CHART FOR BROWSERS");
        moveto(75, midy);
        settextjustify(CENTER_TEXT, CENTER_TEXT);
        settextstyle(TRIPLEX_FONT, VERT_DIR, 3);
        outtext(str);

        getch();

        /* deallocate memory allocated for graphic screen */
        closegraph();
        return 0;
  }