#include <stdio.h>
  #include <conio.h>
  #include <graphics.h>
  #include <dos.h>

  int main() {
        char str[64];
        /* request auto detection */
        int gdriver = DETECT, gmode, err;
        int i, midx, midy, tmp1, tmp2;
        int v[4][2], w[4][2], x[4][2], y[4][2], z[4][2];
        char depart[5][32] = {"ELECTRONICS", "MEDICAL",
                                "MUSIC", "CLOTHING",
                                "SERVICES"};

        /* initialize graphic mode */
        initgraph(&gdriver, &gmode, "C:/TURBOC3/BGI");
        err = graphresult();

        if (err != grOk) {
                /* error occurred */
                printf("Graphics Error: %s",
                                grapherrormsg(err));
                return 0;
        }

        /* mid position in x and y axis */
        midx = getmaxx() / 2;
        midy = getmaxy() / 2;

        /* line at y and x-axis */
        line(70, 0, 70, getmaxy() - 50);
        line(70, getmaxy() - 50, getmaxx(), getmaxy() - 50);

        /* units at y-axis */
        for (i = 0; i < 5; i++) {
                sprintf(str, "%d", 25 * i);
                settextstyle(TRIPLEX_FONT, HORIZ_DIR, 1);
                settextjustify(CENTER_TEXT, CENTER_TEXT);
                moveto(40, getmaxy() - 70 - i * 80);
                outtext(str);
        }

        /* y-axis represents revenue */
        moveto(10, midy);
        settextstyle(TRIPLEX_FONT, VERT_DIR, 3);
        sprintf(str, "%s", "REVENUE");
        outtext(str);

        /* x-axis represent departments */
        moveto(midx, getmaxy() - 10);
        settextstyle(TRIPLEX_FONT, HORIZ_DIR, 1);
        sprintf(str, "%s", "DEPARTMENTS");
        outtext(str);

        tmp1 = getmaxy() - 40;
        tmp2 = 135;

        /* place the departments in x-axis */
        for (i = 0; i < 5; i++) {
                moveto(tmp2, tmp1);
                outtext(depart[i]);
                tmp2 = tmp2 + 110;
        }

        /* set the initial points of vertical bars */
        v[0][0] = 95, v[0][1] = getmaxy() - 51;
        v[1][0] = 175, v[1][1] = getmaxy() - 51;

        w[0][0] = 205, w[0][1] = getmaxy() - 51;
        w[1][0] = 285, w[1][1] = getmaxy() - 51;

        x[0][0] = 315, x[0][1] = getmaxy() - 51;
        x[1][0] = 395, x[1][1] = getmaxy() - 51;

        y[0][0] = 425, y[0][1] = getmaxy() - 51;
        y[1][0] = 505, y[1][1] = getmaxy() - 51;

        z[0][0] = 535, z[0][1] = getmaxy() - 51;
        z[1][0] = 615, z[1][1] = getmaxy() - 51;

        /* animate vertical bar graphs */
        for (i = 0; i < getmaxy() - 100; i++) {
                /* vertical bar 1 - electronics */
                if (i <= getmaxx() - 310) {
                        setcolor(BLUE);
                        line(v[0][0], v[0][1], v[1][0], v[1][1]);
                        v[0][1] = v[0][1] - 1;
                        v[1][1] = v[1][1] - 1;
                }

                /* vertical bar 2 - medical */
                if (i <= getmaxx() - 340) {
                        setcolor(LIGHTRED);
                        line(w[0][0], w[0][1], w[1][0], w[1][1]);
                        w[0][1] = w[0][1] - 1;
                        w[1][1] = w[1][1] - 1;
                }

                /* vertical bar 3 - music */
                if (i <= getmaxx() - 380) {
                        setcolor(LIGHTGREEN);
                        line(x[0][0], x[0][1], x[1][0], x[1][1]);
                        x[0][1] = x[0][1] - 1;
                        x[1][1] = x[1][1] - 1;
                }

                /* vertical bar 4 - clothing */
                if (i <= getmaxx() - 450) {
                        setcolor(DARKGRAY);
                        line(y[0][0], y[0][1], y[1][0], y[1][1]);
                        y[0][1] = y[0][1] - 1;
                        y[1][1] = y[1][1] - 1;
                }

                /* vertical bar 5 - services */
                if (i <= getmaxx() - 550) {
                        setcolor(YELLOW);
                        line(z[0][0], z[0][1], z[1][0], z[1][1]);
                        z[0][1] = z[0][1] - 1;
                        z[1][1] = z[1][1] - 1;
                }

                /* sleep for 25 milliseconds */
                delay(25);
        }

        getch();

        /* deallocate memory allocated for graphic screen */
        closegraph();

        return 0;
  }