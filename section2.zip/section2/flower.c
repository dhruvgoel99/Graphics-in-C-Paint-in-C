#include<stdio.h>

#include<conio.h>

#include<graphics.h>

void main()

{

int gd=DETECT,gm;

initgraph(&gd,&gm,"");

setcolor(CYAN);

/*Write Text*/

settextstyle(4,HORIZ_DIR,5);

outtextxy(250,100,"Flower");

setcolor(RED);

/*create flower*/

circle(320,240,40);

arc(350,200,290,180,32);

arc(375,259,202,118,32);

arc(322,295,140,50,32);

arc(267,265,75,338,32);

arc(282,203,0,263,32);

arc(194,288,300,0,162);

/*create leaf*/

setcolor(GREEN);

arc(361,350,30,160,15);

line(345,348,375,342);

arc(360,340,200,345,15);

getch();

closegraph();

}
