#include<stdio.h>
  #include<graphics.h>
  #include<conio.h>
  void main()
  {
              int gd=DETECT, gm,array[]={320,240,340,220,360,240,360,280,320,280,320,240);
               initgraph(&gd,&gm,� �);                               
               drawpoly(6,array);
               getch();
               closegraph();
}