 #include<stdio.h>
  #include<graphics.h>
  #include<conio.h>
{
    int gd=DETECT,gm;
   initgraph(&gd,&gm," ");
   sector(320,240,0,180,100,50);
    getch();
  closegraph();
}