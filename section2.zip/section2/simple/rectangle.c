#include<stdio.h>
  #include<graphics.h>
  #include<conio.h>
{
    int gd=DETECT,gm;
   initgraph(&gd,&gm," ");
   rectangle(100,200,200,275);
    getch();
  closegraph();
}