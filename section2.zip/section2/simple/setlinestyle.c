#include<stdio.h>
  #include<graphics.h>
  #include<conio.h>
   void main()
{
   int gd = DETECT, gm, i ;
   char arr[100];
   initgraph(&gd, &gm, " ");
     sprintf(arr,"Here are the five line styles enumerated in graphics.h header file:");
    outtextxy(2,10,arr);

   for ( i = 0 ; i < 5 ; i++ )
   {
    setlinestyle(i,0,1);
      if(i==0)
       {   
        sprintf(arr,"(1).");
        outtextxy(60,50,arr);
        line(100,40,300,40);
       sprintf(arr,"line syle : solid");
       outtextxy(100,60,arr);
      }
        if(i==1)
       {   
        sprintf(arr,"(2).");
        outtextxy(60,110,arr);
        line(100,100,300,100);
       sprintf(arr,"line syle :  Dotted");
       outtextxy(100,120,arr);
      }
            if(i==2)
       {   
        sprintf(arr,"(3).");
        outtextxy(60,170,arr);
        line(100,160,300,160);
       sprintf(arr,"line syle :  center line(alternating dashes and dots)");
       outtextxy(100,180,arr);
      }
       if(i==3)
       {   
        sprintf(arr,"(4).");
        outtextxy(60,230,arr);
        line(100,220,300,220);
       sprintf(arr,"line syle :  Dashed");
       outtextxy(100,240,arr);
      }
          if(i==4)
       {   
        sprintf(arr,"(5).");
        outtextxy(60,290,arr);
        setlinestyle(i,15,1);
        line(100,280,300,280);
       sprintf(arr,"line syle :  User-defined");
       outtextxy(100,300,arr);
      }
  }
    getch(); 
   closegraph();
   }