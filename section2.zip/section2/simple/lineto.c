 #include<stdio.h>
  #include<graphics.h>
  #include<conio.h>
   void main()
{
   int gd = DETECT, gm,x,y;
   initgraph(&gd, &gm," ");
   moveto(20,30);
   lineto(320,240);
    getch();
   closegraph();
 }