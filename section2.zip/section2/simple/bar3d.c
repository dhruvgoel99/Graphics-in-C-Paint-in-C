#include<stdio.h>
#include<conio.h>
#include<graphics.h>
void main()
{
    int gd=DETECT,gm;
   initgraph(&gd,&gm,� �);
   bar3d( 100,150,200,200,25,1);
    getch();
  closegraph();
}