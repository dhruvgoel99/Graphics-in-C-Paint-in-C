#include<stdio.h>
#include<conio.h>
#include<graphics.h>
void main()
{
    int gd=DETECT,gm;
   initgraph(&gd,&gm,� �);
  arc(320,240,0,45,100);
  getch();
  closegraph();
}