/*filipoly() * Purpose - fillpoly draws and fills a polygon*/

#include<graphics.h>
#include<stdio.h>
void main()
{ int gdriver=9.gmode=2,i,polyarray[30];
 initgraph(&gdriver,&gmode,"c:\\tc\\");
 printf(�Demo of fil|poly() \n");
setColor(LIGHTRED); 
polyarray[0]=0;
 polyarray[1]=200;
polyarray[2]=50; 
polyarray[3]=300;
polyarray[4]=250; 
polyarray[5]=300;
polyarray[6]=400;
 polyarray[7]=250;
polyarray[8]=325;
polyarray[9]=225;
polyarray[10]=325;
 polyarray[11]=175;
polyarray[12]=300;
polyarray(13]=200;
polyarray[14]=200;
polyarray[15]=150;
 polyarray[16]=275;
polyarray[17]=115;
polyarray(18]=300;
polyarray[1 9)=125
polyarray[20]=300;
 polyarray[21]=100;
polyarray[22]=400;
 polyarray[23]=50;
polyarray[24]=200;
 polyarray[25]=50;
polyarray[26]=100;
 polyarray[27]=100;
polyarray[28]=0;
 polyarray[29]=200;
drawpoly(15,polyarray);
 getch();
 flllpoly(15,polyarray);
 getch();
 closegraph(); } 


