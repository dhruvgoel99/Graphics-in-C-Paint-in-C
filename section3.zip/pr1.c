/* Filling Ellipse fillellipse() */
 /* This program draws an ellipse and then fills it with fillellipses) */
 #include-stolio.h>
#include:graphics.h>
void main()
{ int goriver�9,gmode=2;
 initgraph(&gdriver,&gmode,");
outtext("Demo of fillellipse() \n");
 setcolor(LIGHTRED); 
ellipse(300,100,0,36060,30).
getch(); 
fillellipse(300,100,60,30)
getch(); 
closegraph();
}
