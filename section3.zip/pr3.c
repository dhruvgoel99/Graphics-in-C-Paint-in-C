/*fill circle with floodfill*/
#include<stdio.h>
#include<conio.h>
#include<graphics.h>
void main()
{
    int gd= DETECT, gm;
   initgraph(&gd,&gm,� �);
setcolor(RED);
  circle(100,200,50);
    getch();
floodfill(100,200,LIGHTRED);
getch();
  closegraph();
}
