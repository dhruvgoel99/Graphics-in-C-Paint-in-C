/*Program 5*/
#include <graphics.h>
 #include <stdio, h>
#include <conio, h> 
/* This program draws a polygon(), fills it with patterns from setfillstyle() using fillpoly() */ 
void main()
{ int gdriver=9, gmode=2,i,maxx, maxy, poly[8];
 initgraph(&gdriver, &gmode, "c:\\tc\\");
 maxx = getmaxx();
 maxy = getmaxy();
poly[0] = 20;
 poly[1] = maxy / 2;
 poly[2] = maxx - 20;
 poly[3] = 20;
 poly[4] = maxx - 50;
 poly[5] = maxy - 20;
 poly[6] = maxx / 2;
 poly[7] = maxy / 2;
for(i=EMPTY_FILL; i< USER_FILL; i++)
{ setfillstyle(i, getmaxcolor()); 
fillpoly(4, poly);
 getch(); 
} 
closegraph();
 }
