Program 5
#include <graphics.h>
 #include <stdio, h>
#include <conio, h> 
/* This program draws a polygon(), fills it with patterns from setfillstyle() using fillpoly() */ 
void main()
{ int gdriver=9, gmode=2,i,midx, midy;
int xradius=100,yradius = 50;
 initgraph(&gdriver, &gmode, "c:\\tc\\");
 midx = getmaxx()/2;
 midy = getmaxy()/2;
for(i=EMPTY_FILL; i< USER_FILL; i++)
{ setfillstyle(i, getmaxcolor()); 
fillellipse(midx,midy,xradius,yradius);
 getch(); 
} 
closegraph();
 }
