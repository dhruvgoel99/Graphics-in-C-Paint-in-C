﻿Program 2 .

#include<stdio.h>

#include<graphics.h>

/* Program Displaying text height & width */

void main()

{ int gdriver=9,gmode=2,height,width;

char text[100]; 
initgraph(&gdriver,&gmode,”"); 

outtextxy(10,20,”First Hello from outtextxy()”); 

setcolor(YELLOW);

outtextxy(40.60,"Second Hello from outtextxy()");
height = textheight("Tall");
width = textwidth("Fat");
sprintf(text,"Height of Text = %d, Width of Text = %d ",height,width);
setcolor(LIGHTCYAN);
outtextxy(40,60+height+10,text);
getch();
closegraph();
}
