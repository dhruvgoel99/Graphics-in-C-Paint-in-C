

#include<stdio.h>
#include<conio.h>

char far *scr=(char far*)0xB8000000;

void Cell(char ch,int i,int color)
{
 *(scr+i)=ch; *(scr+i+1)=color;
}
void PopUp(int x1,int y1,int x2,int y2,int color)
{
 int i,j,temp=160;
 int tx1=x1*2+(y1*160-160), tx2=x1*2+y2*160;
 int ty1=x2*2+(y1*160-160), ty2=x2*2+y2*160;

 for(i=tx1+160;i<ty2;i+=160,temp+=160)
 {
  for(j=tx1;j<ty1;j+=2)
   Cell('�',j+temp,7);
  if(i>tx1+160&&i<ty2-160)
  {
   Cell('�',tx1+temp+2,color);
   Cell('�',ty1+temp-4,color);
  }
 }
 Cell('+',tx1+162,color); Cell('+',ty1+156,color);
 Cell('+',tx2+2,color); Cell('+',ty2-4,color);
 for(i=tx1+164,j=2+2;i<ty1+156;i+=2,j+=2)
 {
  Cell('-',i,color);
  Cell('-',tx2+j,color);
 }
}

void HighLight(char *opname,int x1,int x2,int y1,int color)
{
 int tx1=x1*2+(y1*160),tx2=x2*2+(y1*160),i,t=2;
 for(i=tx1;i<=tx2;i+=2)
  Cell('�',i,color);
 if(*opname > 65 && *opname < 89 || *opname > 97 && *opname < 121)
  Cell(*opname,tx1+t,color*16+1);
 else
  Cell(*opname,tx1+t,color*16);
 do
 {
  t+=2;
  opname++;
  Cell(*opname,tx1+t,color*16);
 }while(*opname!='