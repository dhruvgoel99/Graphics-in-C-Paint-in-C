﻿Program 3
#include<stdio.h>

#include<graphics.h>

/* Program diSpl‘a in . . .
Void maino y 9 text ”1 d'fferent Fonts, Sizes & Orientation */

{ int gdriver=9,gmode =2,i;
int font[]={0,1,2,3,4}; 

char *fonttext[]={ “Default fonts",

”Triplex fonts",

“Small fonts”,

"Sans serif fonts”,
“Gothic fonts" }
initgraph(&gdriver,&gmode,""); 

setcolor(LlGHTCYAN);

outtextxy(10,20,”Demo of settextstyle()”);

getch();


for(i=0;i<5;i++)


{ cleardevice();

outtextxy(0,0,”Fonts available : “);

outtextxy(10,100,fonttext[i]);

getch(); }


for(i=1;i<11;i++)


{ cleardevice(); 
 
settextstyle(TRlPLEX_FONT,HORIZ_DIR,i);

outtextxy(10,200,”Sizing”);

getch(); 
}


cleardevice();


settextstyle(TlPLEX_FONT,HORIZ_DIR,6);


outtextxy(10,200,”HORIZONTAL”);


settextstyle(TRlPLEX_FONT,VERT_DIR,9);


outtextxy(400, 10,”VERTICAL");


getch();

closegraph(); }