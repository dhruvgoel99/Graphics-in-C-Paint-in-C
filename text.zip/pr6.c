Program 6
#include<stdio.h>
#include<graphics.h>
/* Program to demonstrate Text Justification */
void main()
{int gdriver=9,gmode=2,x,y; 
initgraph(&gdriver,&gmode,""); 
x=getmaxx()/2;
 y=getmaxy()/2;
 settextstyle(TRIPLEX_FONT,HORIZ_DIR,4);
 setColor(LIGHTCYAN); 
line(x-250,y,x+250,y); 
line(x,y-100,x,y+100);
settextjustify(LEFT_TEXT,BOTTOM_TEXT);
 setColor{YELLOW);
outtextxy(x,y,�1. LeftBottom");
settextjustify(LEFT_TEXT,TOP_TEXT);
setColor{YELLOW);
outtextxy(x,y,"2 Left Top");
settextjustify(RIGHT_TEXT,BOTTOM_TEXT):
setColor(YELLOW);
outtextxy(x,y,"3. Right Bottom");
settextjustify(RIGHT_TEXT,TOP_TEXT);
setcolor(YELLOW);
outtextxy(x,y,"4. Right Top");
getch();
cleardevice();
 line(x-250,y,x+250,y);
 line(x,y-100,x,y+100);
settextjustify(CENTER_TEXT,CENTER_TEXT);
setcolor(LIGHTCYAN); 
outtextxy(x,y,"5. Center");
getch();
closegraph();
}
