/*Program 8*/
#include<graphics.h>
#include<bios.h> 
#include<stdio.h>
 /*This Program allows data-entry in graphics mode.(Ver1.1) */
void main()
{ int gdriver=9,gmode=2,p; 
char name[40], number[8], ans[3];
initgraph(&gdriver,&gmode,"");
setcolor(LIGHTBLUE);
 rectangle(1,1,getmaxx()-1, getmaxy()-1);
 while(1)
{
settextstyle(TRIPLEX_FONT, HORIZ_DIR,4);
 settextjustify(CENTER_TEXT,CENTER_TEXT);
 setcolor(YELLOW);
 outtextxy(getmaxx()/2,20, "Telephone Services"); 
settextstyle(TRIPLEX_FONT, HORIZ_DIR,2);
 settextjustify(LEFT_TEXT,TOP_TEXT);
setcolor(LIGHTGREEN); 
outtextxy(5,60,"Name : "); 
outtextxy(5,100,"Number : �)
setcolor(LIGHTCYAN);
intextxy(100,60, name,30);
intextxy(100,100,number 8);
setcolor(LIGHTMAGENTA);
outtextxy(10,300,"Want to continue ? "); 
intextxy(500,300, ans,3);
p=strcmp("N",ans)
if(p==0)
break;
else
{sefillstyle(SOLID_FILL, BLACK);
bar(2,2,getmaxx()-2,getmaxy()-2):}}
getch();
closegraph(); }
int intextxy(int x, int y, char*str, int len)
{int i; 
char *temp; 
unsigned int ch; 
temp=str; 
i=-1;
settextjustify(LEFT_TEXT,TOP_TEXT)
while(1)
{if((ch &0x00FF) ||  (ch>>8)==75)
 i++;
rectangle(x,y,x+16*len,y+25);
 ch=bioskey(0);
 if((ch &0x00FF)==13) 
{temp[i]=0; 
break;} 
else if(((ch>>8)==75 && (ch &0x00FF)==0) || (ch &0x00FF)==8)
{if(i>1)
 {i=i+2;
 temp[i+1]=0;}
else
{ i=-1;
 temp[i+1]=0;
putchar(7);
setfillstyle(SOLID_FILL, BLACK);
bar(x+1,y,x+16*len-1,y+25);
outtextxy(x,y,temp);
else if(i>len-2) && (( ch &0x00FF) != 0))
{putchar(7);
return 0;
else if(( ch & 0x00FF) != 0)
{temp[i] = ch &0x00FF;
temp[i+1] = 0;
outtextxy(x,y,temp); }}
return 0; }




temp[i+1]=0; putchar(7);} � -semsoup_F?* bar(x+1y,x+16�len-1y+25);
out(extxy(x,y,temp); else if((i>|en-2)&& ((ch30x00FF)!=0))
{putchar(7);
temp[i+1]=0; �tx�(x,y,temp); }} return 0;} Output TelephoneServices Name :Lakhotia ComputerCentre ____________)~~
Number 339328
?ent so Continue ? .
