#include <graphics.h>
#include <stdio.h>
#include <conio.h>
Void main()
{
textcolor(4);          
/*  OR  textcolor(4+BLINK)*/
textbackground(3);
cprintf(�Raju Upadhyaya�);
getch();
}