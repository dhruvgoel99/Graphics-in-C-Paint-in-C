 #include<stdio.h>
  #include<graphics.h>
  #include<conio.h>
   void main()
  {
              int gd=DETECT, gm;
               initgraph(&gd,&gm," ");
               outtextxy(30,100,"C graphics programming is too interesting");
               getch();
               closegraph();
}