﻿/* Dispiaying text with moveto(), 
#include<stdio.h>
#include<graphics.h>
void main()
{int gdriver=9,gmode=2; 
 initgraph(&gdriver,&gmode.””); 
setcolor(YELLOW);

moveto(10,100);

 outtext(“HelIo Everybody”);
 
getch();
outtextxy(10,150,”Hello Everybody”);
getch();
closegraph(); 
}