#include<stdio.h>
#include<conio.h>
#include<graphics.h>
#include<stdlib.h>
char *fname[]={"DEFAULT font","TRIPLEX font","SMALL font","SANS SERIF font","GOTHIC font"};
void main(void)
{
int gd=DETECT,gm,error;
int style,midx,midy;
int size=1;
initgraph(&gd,&gm,"");
midx=getmaxx()/2;
midy=getmaxy()/2;
settextjustify(CENTER_TEXT,CENTER_TEXT);
for(;style<=GOTHIC_FONT;style++)
{
cleardevice();
if(=TRIPLEX_FONT)
size=4;
settextstyle(style,HORIZ_DIR,size);
outtextxy(midx,midy,fname[style]);
getch();
}
closegraph();
}