#include<stdio.h>
#include<conio.h>
int main()
{
    clrscr();
    textcolor(BLUE);  // Change font colour to blue
    textbackground(WHITE); //change the background colour to white
    cprintf("Color is Blue with white background\n\n");
    clrscr();
    textcolor(RED+BLINK);//this one is blinking the text
    cprintf("Color is RED with blinking\n\n");
    return 0;
}