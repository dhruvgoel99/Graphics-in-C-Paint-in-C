#include<stdio.h>
  #include<graphics.h>
  #include<conio.h>
   void main()
  {
              int gd=DETECT, gm;
               initgraph(&gd,&gm," ");
               outtext("C graphics programming is too interesting");
               getch();
               closegraph();
}