#include<stdio.h>
#include<conio.h>
#include<ctype.h>
#include<string.h>

int color=15;
int speed=50;
char String[25];

char colors[]={"USE { R, G, g, B, b, Y, M, C, W } for color | USE 0-9 for speed"};
char *StringMenu[]={"  String Animation",
		    "---------------------",
		    "  1-> Left To Right",
		    "  2-> Right To Left",
		    "  3-> Top To Bottom",
		    "  4-> Bottom To Top",
		    "  5-> Exit ",
		    "---------------------",
		    " Enter the Choice : [ ]"};

void SetColorAndSpeed(char cs)
{
 switch(cs)
 {
  case 'R':case 'r': textcolor(RED);break;
  case 'B':          textcolor(BROWN);break;
  case 'b':          textcolor(BLUE);break;
  case 'G':          textcolor(DARKGRAY);break;
  case 'g':          textcolor(GREEN);break;
  case 'Y':case 'y': textcolor(YELLOW);break;
  case 'M':case 'm': textcolor(MAGENTA);break;
  case 'C':case 'c': textcolor(CYAN);break;
  case 'W':case 'w': textcolor(WHITE);break;
 }
 if(cs > 47 && cs < 58)
 speed = (58-cs)*25+1;
}

void ShowColorSpeed()
{
 int i;
 for(i=1;i<=80;i++)
 {
  gotoxy(i,24);
  printf("-");
 }
 gotoxy(10,25);
 printf("%s",colors);
}
void ShowMenu()
{
 int i;
 clrscr();
 for(i=0;i<9;i++)
 {
  gotoxy(30,7+i);
  printf("%s",StringMenu[i]);
 }
}
void DisplayMsg(int x,int y,char msg[])
{
 int i,prev;
   gotoxy(x,y);
   printf("%s",msg);
   getch();
   gotoxy(x,y);
   for(i=0;msg[i];i++)
   {
    cprintf(" ");
    delay(25);
   }
}
void GetString()
{
 clrscr();
 gotoxy(20,12);
 printf("Enter the String : ");
 gets(String);
}
char GetChoice()
{
 char ch;
 do
 {
   gotoxy(51,15);  ch=getche();  gotoxy(51,15);
  if(!(ch>='1' && ch <='5'))
   DisplayMsg(28,18,"Enter Correct Choice !");
  if(ch=='5')
   exit(0);
 }while(!(ch>='1' && ch <='5'));
 GetString();
 clrscr();
 textcolor(15);
 _setcursortype(0);
 DisplayMsg(26,12,"Press Any Key to Animate !");
 ShowColorSpeed();
 return ch;
}

void LeftToRight()
{
 int i,j;
 gotoxy(2,12);
 printf("%s",String);
 for(i=strlen(String)-1;i>=0;i--)
 {
  for(j=2;String[i]!=' ' && j<60;j++)
  {
   if(kbhit())
    SetColorAndSpeed(getch());
   gotoxy(i+j,12);
   cprintf(" ");
   gotoxy(i+j+1,12);
   cprintf("%c",String[i]);
   delay(speed);
  }
 }
 getch();
 _setcursortype(2);
 textcolor(7);
}
void RightToLeft()
{
 int i,j;
 gotoxy(60,12);
 printf("%s",String);
 for(i=0;String[i];i++)
 {
  for(j=60;String[i]!=' ' && j>=2;j--)
  {
   if(kbhit())
    SetColorAndSpeed(getch());
   gotoxy(i+j,12);
   cprintf(" ");
   gotoxy(i+j-1,12);
   cprintf("%c",String[i]);
   delay(speed);
  }
 }
 getch();
 _setcursortype(2);
 textcolor(7);
}
void TopToBottom()
{
 int i,j;
 gotoxy(30,22);
 printf("%s",String);
 for(i=0;i[String];i++)
 {
  for(j=21;String[i]!=' ' && j>=5;j--)
  {
   if(kbhit())
    SetColorAndSpeed(getch());
   gotoxy(30+i,j+1);
   cprintf(" ");
   gotoxy(30+i,j);
   cprintf("%c",String[i]);
   delay(speed);
  }
 }
 getch();
 _setcursortype(2);
 textcolor(7);
}
void BottomToTop()
{
 int i,j;
 gotoxy(30,5);
 printf("%s",String);
 for(i=strlen(String)-1;i>=0;i--)
 {
  for(j=5;String[i]!=' ' && j<23;j++)
  {
   if(kbhit())
    SetColorAndSpeed(getch());
   gotoxy(30+i,j-1);
   cprintf(" ");
   gotoxy(30+i,j);
   cprintf("%c",String[i]);
   delay(speed);
  }
 }
 getch();
 _setcursortype(2);
 textcolor(7);
}
void main()
{
  do
  {
   ShowMenu();
   switch(GetChoice())
   {
    case '1':
	   LeftToRight();
	   break;
    case '2':
	   RightToLeft();
	   break;
    case '3':
	   TopToBottom();
	   break;
    case '4':
	   BottomToTop();
	   break;
   }
  }while(1);
}


