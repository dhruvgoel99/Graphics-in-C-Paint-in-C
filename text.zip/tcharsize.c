#include<stdio.h>
#include<conio.h>
#include<graphics.h>
void main(void)
{
int gd=DETECT,gm;
clrscr();
initgraph(&gd,&gm,"");
settextstyle(TRIPLEX_FONT,HORIZ_DIR,3);
outtextxy(0,0,"normal");
outtextxy(0,80,"small");
outtextxy(0,150,"large");
outtextxy(0,260,"X elongation");
outtextxy(0,360,"Y elongation");
outtextxy(0,30,"comparew size");
setusercharsize(1,2,1,2);
outtextxy(0,110,"compare size");
setusercharsize(2,1,2,1);
outtextxy(0,110,"compare size");
setusercharsize(2,1,1,1);
outtextxy(0,110,"compare size");
setusercharsize(1,1,2,1);
outtextxy(0,110,"compare size");
getch();
closegraph();
}