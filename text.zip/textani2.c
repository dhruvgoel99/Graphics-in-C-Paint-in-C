//program for text animation//

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<graphics.h>
#include<dos.h>

void main()
{
  int x1=600,y1=12,x2=100,y2=100;
  int shape=1,ranc=1,ranp;
  int gd = DETECT,gm;
  initgraph(&gd,&gm,"\\tc\\bgi");
  cleardevice();
  for(;;x1++)
  {
  if(x1>=250)
  {
     ranc=random(600);
     x1=0;
     x2=0;
     y1=getmaxx();
     y2=getmaxy();
     shape=(shape+1)%3;
   }
   setcolor(random(19));
   outtextxy(150,175,"*RAJU*   ");
   outtextxy(640,480,"*#&@*");
   //setcolor(yellow);
   settextstyle(1,0,5);
   outtextxy(177,250,"  *UPADHYAYA*");
   x2++;
   // y1__;
   // y2__;
   delay(100);
 }
  closegraph();
}