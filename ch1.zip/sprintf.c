/* sprintf function*/

#include <stdio.h>
int main()
{
    char birthday[12];
    int  day, month, year;
    printf("Enter your birth month (1-12): ");
    scanf("%d",&month);
    printf("Enter your birth day: ");
    scanf("%d",&day);
    printf("Enter your birth year: ");
    scanf("%d",&year);
    sprintf(birthday,"%d/%d/%d",month,day,year);
    printf("I shall wish you a happy birthday on %sn", birthday);
    return(0);
}
