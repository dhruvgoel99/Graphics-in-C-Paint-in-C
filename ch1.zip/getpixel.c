/*Program getpixel*/
#include<stdio.h>
 #include<graphics.h>
 #include<conio.h> 
void main() 
{ int gd=DETECT, gm, col; 
char a[50]; 
initgraph(&gd, &gm," "); 
Putpixel (320,240,RED); 
col=getpixel(320,240); 
sprintf(a,"color of pixel at location (320,240) is %d", y); 
outtextxy(30,100,a); 
getch();
 closegraph(); }