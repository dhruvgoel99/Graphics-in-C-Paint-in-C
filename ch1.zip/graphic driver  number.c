#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
 /* This program returns graphic driver number*/

int main(void)
{
 
  /* request auto detection */
  int gdriver = DETECT, gmode, errorcode;
  
  /* initialize graphics mode */
  initgraph(&gdriver, &gmode, "");
  
  /* read result of initialization */
  errorcode = graphresult();
  
  if (errorcode != grOk) /* an error occurred */
  {
    printf("Graphics error: %s\n", grapherrormsg(errorcode));
    printf("Press any key to halt:");
    getch();
    exit(1); /* return with error code */
  }
  
  /* print a graphic driver number */

  printf("Graphics Driver Number: %d\n", gdriver);  
  /* clean up */
  getch();
  closegraph();
  return 0;
}