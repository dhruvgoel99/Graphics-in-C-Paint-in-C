#include<stdio.h>
#include<conio.h>
#include<graphics.h>
/* getfillpattern example */
main()
 {
 int gd=DETECT,gm,error;
 char pattern[8] = {0x00, 0x70, 0x20,0x27, 0x25, 0x27, 0x04, 0x04};
 initgraph(&gd,&gm,"f:\\tc\\bgi");
 error = graphresult();
 if (error != grOk)
 {
 printf("Graphics error occurred");
 printf("Press any key to halt:");
 getch();
 exit(1);
 }
 setbkcolor(BLUE);
 setcolor(getmaxcolor());
 setfillpattern(pattern,getmaxcolor()); /* select a user-defined fill pattern */
 bar(30, 30, getmaxx()-30, getmaxy()-30);
 outtextxy(getmaxx()-250,getmaxy()-20,"www.rajuExpert.com");
 getch();
 getfillpattern(pattern); /* get the current user-defined fill pattern */
 pattern[0] -= 5; /* alter the pattern we grabbed */
 pattern[1] -= 10;
 pattern[2] += 10;
 pattern[3] -= 15;
 setfillpattern(pattern, getmaxcolor());
 /* fill the screen with the new pattern */
 bar(30, 30, getmaxx()-30, getmaxy()-30);
 outtextxy(getmaxx()-250,getmaxy()-20,"www.rajuExpert.com");
 getch();
 closegraph();
 }