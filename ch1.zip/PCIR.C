#include<stdio.h> 
#include<conio.h> 
#include<graphics.h> 
void main() 
{ int gd=DETECT,gm; 
initgraph(&gd,&gm," "); 
putpixel(320,240,RED);
circle(320,240,10);
setcolor(GREEN);
circle(320,240,100); 
outtext("enter any character to clear the screen:"); 
getch();
 cleardevice(); 
outtext("enter any character to exit");
getch();
 closegraph();
 }