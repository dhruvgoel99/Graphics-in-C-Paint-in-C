/* getdrivername example */ 
#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

main()
{

   /* request autodetection */
   int gdriver = DETECT, gmode, errorcode;

   /* stores the device driver name */
   char *drivername;
   /* initialize graphics and local variables */
   initgraph(&gdriver, &gmode, "c:\\tc\\");
   /* read result of initialization */
   errorcode = graphresult();

   if (errorcode != grOk)

   { /* an error occurred */

      printf("Graphics error: %s\n", grapherrormsg(errorcode));

      printf("Press any key to halt:");

      getch();

      exit(1);               /* terminate with an error code */

   }

   setcolor(getmaxcolor());
      /* get the name of the device driver in use */

   drivername = getdrivername();

   /* for centering text onscreen */

   settextjustify(CENTER_TEXT, CENTER_TEXT);

   /* output the name of the driver */

   outtextxy(getmaxx() / 2, getmaxy() / 2, drivername);

   /* clean up */

   getch();

   closegraph();

}
