/*Program: circle*/
#include<stdio.h> 
#include<conio.h> 
#include<graphics.h> 
main()
{ int gd=DETECT,gm;
initgraph(&gd,&gm,"c:\\tc\\");
circle(320,240,100);
getch();
closegraph();
 }
