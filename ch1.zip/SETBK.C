#include<stdio.h> 
#include<graphics.h>
#include<conio.h>
main()
{ int gd=DETECT, gm;
initgraph(&gd,&gm,"c:\\tc\\");
setbkcolor(GREEN);
 circle(320,240,100);
 getch();
 closegraph(); }
