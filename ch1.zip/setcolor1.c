 /*Program setcolor*/
#include<stdio.h>
 #include<graphics.h>
 #include<conio.h> 
void main() 
{ int gd=DETECT,gm; initgraph(&gd,&gm," ");
 setcolor(GREEN); 
circle(320,240,100); 
setcolor(RED); 
outtextxy(320,80."It is circle"); 
getch(); 
closegraph(); }
